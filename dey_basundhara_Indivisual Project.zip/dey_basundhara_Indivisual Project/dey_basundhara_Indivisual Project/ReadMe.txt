To play naration:

1. Open the ppt.
2. Go to SlideShow.
3. Check all the boxes, play narations, use timings, show media controls.
4. Click "From Begining"

I have notes written in each slide also I have narated vocally and recoed them in the PPT.